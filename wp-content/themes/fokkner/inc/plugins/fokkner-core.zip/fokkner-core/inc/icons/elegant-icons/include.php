<?php

include_once FOKKNER_CORE_INC_PATH . '/icons/elegant-icons/class-fokknercore-elegant-icons-pack.php';
