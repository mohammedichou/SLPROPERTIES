<div class="qodef-media-section">
	<div class="qodef-img-section qodef-img-holder-inner active">
		<?php echo fokkner_core_get_template_part( 'plugins/property/post-types/property/shortcodes/property-image-map-gallery', 'templates/parts/main-slider', '', $params ); ?>

		<?php echo fokkner_core_get_template_part( 'plugins/property/post-types/property/shortcodes/property-image-map-gallery', 'templates/parts/thumbnail-slider', '', $params ); ?>
	</div>
	<?php echo fokkner_core_get_template_part( 'plugins/property/post-types/property/shortcodes/property-image-map-gallery', 'templates/parts/video', '', $params ); ?>

	<?php echo fokkner_core_get_template_part( 'plugins/property/post-types/property/shortcodes/property-image-map-gallery', 'templates/parts/video', '360', $params ); ?>
</div>
