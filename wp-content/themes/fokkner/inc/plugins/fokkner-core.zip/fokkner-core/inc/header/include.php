<?php

include_once FOKKNER_CORE_INC_PATH . '/header/helper.php';
include_once FOKKNER_CORE_INC_PATH . '/header/class-fokknercore-header.php';
include_once FOKKNER_CORE_INC_PATH . '/header/class-fokknercore-headers.php';
include_once FOKKNER_CORE_INC_PATH . '/header/template-functions.php';
