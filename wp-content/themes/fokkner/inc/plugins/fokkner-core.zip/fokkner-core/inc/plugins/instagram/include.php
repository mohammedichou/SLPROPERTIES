<?php

include_once FOKKNER_CORE_PLUGINS_PATH . '/instagram/helper.php';
