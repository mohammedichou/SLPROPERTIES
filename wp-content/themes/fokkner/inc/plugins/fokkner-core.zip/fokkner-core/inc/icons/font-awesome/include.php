<?php

include_once FOKKNER_CORE_INC_PATH . '/icons/font-awesome/class-fokknercore-font-awesome-pack.php';
