<?php

include_once FOKKNER_CORE_INC_PATH . '/core-dashboard/rest/class-fokknercore-dashboard-rest-api.php';
