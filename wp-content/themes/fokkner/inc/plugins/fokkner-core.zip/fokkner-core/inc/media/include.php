<?php

include_once FOKKNER_CORE_INC_PATH . '/media/helper.php';
