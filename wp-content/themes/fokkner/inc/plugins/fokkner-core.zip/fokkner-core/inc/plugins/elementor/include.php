<?php

if ( qode_framework_is_installed( 'elementor' ) ) {
	include_once FOKKNER_CORE_PLUGINS_PATH . '/elementor/helper.php';
	include_once FOKKNER_CORE_PLUGINS_PATH . '/elementor/class-fokknercore-elementor-section-handler.php';
}
