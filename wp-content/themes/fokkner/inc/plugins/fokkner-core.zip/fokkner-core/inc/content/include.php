<?php

include_once FOKKNER_CORE_INC_PATH . '/content/helper.php';
