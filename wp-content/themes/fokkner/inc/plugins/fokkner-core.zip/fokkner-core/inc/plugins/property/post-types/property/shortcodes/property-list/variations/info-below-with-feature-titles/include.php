<?php

include_once FOKKNER_CORE_PLUGINS_PATH . '/property/post-types/property/shortcodes/property-list/variations/info-below-with-feature-titles/info-below-with-feature-titles.php';
