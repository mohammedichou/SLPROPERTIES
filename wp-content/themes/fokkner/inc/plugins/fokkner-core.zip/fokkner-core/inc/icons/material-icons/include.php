<?php

include_once FOKKNER_CORE_INC_PATH . '/icons/material-icons/class-fokknercore-material-icons-pack.php';
