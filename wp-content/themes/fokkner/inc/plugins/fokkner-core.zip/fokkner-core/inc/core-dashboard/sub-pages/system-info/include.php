<?php

include_once FOKKNER_CORE_INC_PATH . '/core-dashboard/sub-pages/system-info/class-fokknercore-dashboard-system-info-page.php';
