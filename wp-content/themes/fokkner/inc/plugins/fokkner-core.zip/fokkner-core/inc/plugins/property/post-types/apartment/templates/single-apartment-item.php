<?php

get_header();

fokkner_core_template_part( 'plugins/property/post-types/apartment', 'templates/content' );

get_footer();
