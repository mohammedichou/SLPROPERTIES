<?php

include_once FOKKNER_CORE_PLUGINS_PATH . '/property/post-types/property/shortcodes/property-info-table/class-fokknercore-property-info-table-shortcode.php';
