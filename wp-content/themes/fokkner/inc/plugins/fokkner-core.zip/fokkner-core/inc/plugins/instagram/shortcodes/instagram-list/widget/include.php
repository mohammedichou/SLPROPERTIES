<?php

include_once FOKKNER_CORE_PLUGINS_PATH . '/instagram/shortcodes/instagram-list/widget/class-fokknercore-instagram-list-widget.php';
