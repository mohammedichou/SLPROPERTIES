<?php

include_once FOKKNER_CORE_PLUGINS_PATH . '/property/post-types/helper.php';
