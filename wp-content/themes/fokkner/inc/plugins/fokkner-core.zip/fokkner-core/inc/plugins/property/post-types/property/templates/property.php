<div class="qodef-property qodef-m">
	<?php
	// Include events posts loop
	fokkner_core_template_part( 'plugins/property/post-types/property', 'templates/parts/loop' );
	?>
</div>
