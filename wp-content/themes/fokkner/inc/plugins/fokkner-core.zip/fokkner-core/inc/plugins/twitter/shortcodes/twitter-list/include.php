<?php

include_once FOKKNER_CORE_PLUGINS_PATH . '/twitter/shortcodes/twitter-list/class-fokknercore-twitter-list-shortcode.php';
