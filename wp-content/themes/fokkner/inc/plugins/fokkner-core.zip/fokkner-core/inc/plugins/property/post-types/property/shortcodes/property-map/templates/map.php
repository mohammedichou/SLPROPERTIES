<div class="qodef-map" <?php qode_framework_inline_style( $map_styles ); ?>>
	<?php echo fokkner_core_get_multiple_map( $query_array ); ?>
</div>
