<?php

include_once FOKKNER_CORE_PLUGINS_PATH . '/woocommerce/plugins/yith-wishlist/helper.php';
include_once FOKKNER_CORE_PLUGINS_PATH . '/woocommerce/plugins/yith-wishlist/class-fokknercore-woocommerce-yith-wishlist.php';
