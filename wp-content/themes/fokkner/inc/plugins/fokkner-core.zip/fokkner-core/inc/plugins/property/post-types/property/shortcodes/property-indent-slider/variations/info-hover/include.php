<?php

include_once FOKKNER_CORE_PLUGINS_PATH . '/property/post-types/property/shortcodes/property-indent-slider/variations/info-hover/info-hover.php';
