<?php

include_once FOKKNER_CORE_INC_PATH . '/icons/property-icons/class-fokknercore-property-pack.php';
