<?php

include_once FOKKNER_CORE_INC_PATH . '/icons/linear-icons/class-fokknercore-linear-icons-pack.php';
