<?php
// Include logo
fokkner_core_get_header_logo_image();

// Include main navigation
fokkner_core_template_part( 'header', 'templates/parts/navigation' );

// Include widget area one
fokkner_core_get_header_widget_area();
