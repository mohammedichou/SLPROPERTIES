<?php
echo fokkner_core_get_template_part( 'plugins/property/post-types/property/shortcodes/property-info/', 'templates/post-info/title', '', $params );
echo fokkner_core_get_template_part( 'plugins/property/post-types/property/shortcodes/property-info/', 'templates/post-info/excerpt', '', $params );
echo fokkner_core_get_template_part( 'plugins/property/post-types/property/shortcodes/property-info/', 'templates/post-info/feature-items', '', $params );
echo fokkner_core_get_template_part( 'plugins/property/post-types/property/shortcodes/property-info/', 'templates/post-info/read-more', '', $params );
