<?php

include_once FOKKNER_CORE_INC_PATH . '/media/list-image-sizes/list-image-sizes.php';
