<?php

include_once FOKKNER_CORE_PLUGINS_PATH . '/property/post-types/property/shortcodes/property-list/variations/info-over-image/info-over-image.php';
