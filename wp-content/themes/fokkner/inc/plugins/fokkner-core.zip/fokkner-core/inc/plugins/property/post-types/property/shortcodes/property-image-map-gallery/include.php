<?php

include_once FOKKNER_CORE_PLUGINS_PATH . '/property/post-types/property/shortcodes/property-image-map-gallery/class-fokknercore-property-image-map-gallery-shortcode.php';
include_once FOKKNER_CORE_PLUGINS_PATH . '/property/post-types/property/shortcodes/property-image-map-gallery/class-fokknercore-property-image-map-gallery-child-shortcode.php';

include_once FOKKNER_CORE_PLUGINS_PATH . '/property/post-types/property/shortcodes/property-image-map-gallery/functions.php';
