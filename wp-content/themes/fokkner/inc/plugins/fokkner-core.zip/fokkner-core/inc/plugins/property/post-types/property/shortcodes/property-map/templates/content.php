<div <?php qode_framework_class_attribute( $holder_classes ); ?>>
	<?php
	// include map
	fokkner_core_template_part( 'plugins/property/post-types/property/shortcodes/property-map', 'templates/map', '', $params );
	?>
</div>
