<div class="qodef-apartment qodef-m">
	<?php
	// Include events posts loop
	fokkner_core_template_part( 'plugins/property/post-types/apartment', 'templates/parts/loop' );
	?>
</div>
