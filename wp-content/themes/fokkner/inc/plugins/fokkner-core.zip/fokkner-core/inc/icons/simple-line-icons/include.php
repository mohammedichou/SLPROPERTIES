<?php

include_once FOKKNER_CORE_INC_PATH . '/icons/simple-line-icons/class-fokknercore-simple-line-icons-pack.php';
