<?php

include_once FOKKNER_CORE_INC_PATH . '/icons/ionicons/class-fokknercore-ionicons-pack.php';
