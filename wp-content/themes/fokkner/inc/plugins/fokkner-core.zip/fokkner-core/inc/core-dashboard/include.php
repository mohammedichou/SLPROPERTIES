<?php

include_once FOKKNER_CORE_INC_PATH . '/core-dashboard/class-fokknercore-dashboard.php';
