<?php

include_once FOKKNER_CORE_PLUGINS_PATH . '/woocommerce/class-fokknercore-woocommerce.php';
