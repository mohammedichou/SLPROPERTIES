<?php

include_once FOKKNER_CORE_INC_PATH . '/blog/shortcodes/blog-list/variations/text-below/text-below.php';
