<?php

include_once FOKKNER_CORE_PLUGINS_PATH . '/contact-form-7/class-fokknercore-contact-form-7.php';
