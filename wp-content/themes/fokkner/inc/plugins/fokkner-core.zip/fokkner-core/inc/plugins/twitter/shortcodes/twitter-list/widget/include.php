<?php

include_once FOKKNER_CORE_PLUGINS_PATH . '/twitter/shortcodes/twitter-list/widget/class-fokknercore-twitter-list-widget.php';
