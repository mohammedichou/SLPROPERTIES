<?php

include_once FOKKNER_CORE_INC_PATH . '/icons/linea-icons/class-fokknercore-linea-icons-pack.php';
