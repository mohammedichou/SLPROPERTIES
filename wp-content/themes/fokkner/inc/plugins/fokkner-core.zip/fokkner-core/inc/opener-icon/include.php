<?php

include_once FOKKNER_CORE_INC_PATH . '/opener-icon/helper.php';
