<?php

include_once FOKKNER_CORE_INC_PATH . '/mobile-header/helper.php';
include_once FOKKNER_CORE_INC_PATH . '/mobile-header/class-fokknercore-mobile-header.php';
include_once FOKKNER_CORE_INC_PATH . '/mobile-header/class-fokknercore-mobile-headers.php';
include_once FOKKNER_CORE_INC_PATH . '/mobile-header/template-functions.php';
