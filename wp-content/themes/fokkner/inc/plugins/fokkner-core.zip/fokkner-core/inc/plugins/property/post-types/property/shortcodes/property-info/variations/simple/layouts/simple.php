<?php

echo fokkner_core_get_template_part( 'plugins/property/post-types/property/shortcodes/property-info/', 'templates/post-info/feature-items', '', $params );
