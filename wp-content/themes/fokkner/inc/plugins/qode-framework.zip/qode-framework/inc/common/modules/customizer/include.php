<?php

require_once QODE_FRAMEWORK_INC_PATH . '/common/modules/customizer/core/class-qodeframeworkoptionscustomizer.php';
require_once QODE_FRAMEWORK_INC_PATH . '/common/modules/customizer/core/class-qodeframeworkpagecustomizer.php';
